﻿
namespace EDNEVNIK
{
    partial class Osoba
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxIme = new System.Windows.Forms.TextBox();
            this.textBoxPrezime = new System.Windows.Forms.TextBox();
            this.textBoxAdesa = new System.Windows.Forms.TextBox();
            this.textBoxJMBG = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxLozinka = new System.Windows.Forms.TextBox();
            this.textBoxUloga = new System.Windows.Forms.TextBox();
            this.lid = new System.Windows.Forms.Label();
            this.lime = new System.Windows.Forms.Label();
            this.lprezime = new System.Windows.Forms.Label();
            this.ladresa = new System.Windows.Forms.Label();
            this.ljmbg = new System.Windows.Forms.Label();
            this.lemail = new System.Windows.Forms.Label();
            this.lPassvord = new System.Windows.Forms.Label();
            this.lUloga = new System.Windows.Forms.Label();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxId
            // 
            this.textBoxId.Enabled = false;
            this.textBoxId.Location = new System.Drawing.Point(118, 31);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(154, 20);
            this.textBoxId.TabIndex = 0;
            // 
            // textBoxIme
            // 
            this.textBoxIme.Location = new System.Drawing.Point(118, 74);
            this.textBoxIme.Name = "textBoxIme";
            this.textBoxIme.Size = new System.Drawing.Size(154, 20);
            this.textBoxIme.TabIndex = 1;
            // 
            // textBoxPrezime
            // 
            this.textBoxPrezime.Location = new System.Drawing.Point(118, 109);
            this.textBoxPrezime.Name = "textBoxPrezime";
            this.textBoxPrezime.Size = new System.Drawing.Size(154, 20);
            this.textBoxPrezime.TabIndex = 2;
            // 
            // textBoxAdesa
            // 
            this.textBoxAdesa.Location = new System.Drawing.Point(118, 144);
            this.textBoxAdesa.Name = "textBoxAdesa";
            this.textBoxAdesa.Size = new System.Drawing.Size(154, 20);
            this.textBoxAdesa.TabIndex = 3;
            // 
            // textBoxJMBG
            // 
            this.textBoxJMBG.Location = new System.Drawing.Point(118, 177);
            this.textBoxJMBG.Name = "textBoxJMBG";
            this.textBoxJMBG.Size = new System.Drawing.Size(154, 20);
            this.textBoxJMBG.TabIndex = 4;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(118, 211);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(154, 20);
            this.textBoxEmail.TabIndex = 5;
            // 
            // textBoxLozinka
            // 
            this.textBoxLozinka.Location = new System.Drawing.Point(118, 240);
            this.textBoxLozinka.Name = "textBoxLozinka";
            this.textBoxLozinka.Size = new System.Drawing.Size(154, 20);
            this.textBoxLozinka.TabIndex = 6;
            // 
            // textBoxUloga
            // 
            this.textBoxUloga.Location = new System.Drawing.Point(118, 272);
            this.textBoxUloga.Name = "textBoxUloga";
            this.textBoxUloga.Size = new System.Drawing.Size(154, 20);
            this.textBoxUloga.TabIndex = 7;
            // 
            // lid
            // 
            this.lid.AutoSize = true;
            this.lid.Location = new System.Drawing.Point(30, 38);
            this.lid.Name = "lid";
            this.lid.Size = new System.Drawing.Size(18, 13);
            this.lid.TabIndex = 8;
            this.lid.Text = "ID";
            // 
            // lime
            // 
            this.lime.AutoSize = true;
            this.lime.Location = new System.Drawing.Point(30, 74);
            this.lime.Name = "lime";
            this.lime.Size = new System.Drawing.Size(24, 13);
            this.lime.TabIndex = 9;
            this.lime.Text = "Ime";
            // 
            // lprezime
            // 
            this.lprezime.AutoSize = true;
            this.lprezime.Location = new System.Drawing.Point(22, 109);
            this.lprezime.Name = "lprezime";
            this.lprezime.Size = new System.Drawing.Size(44, 13);
            this.lprezime.TabIndex = 10;
            this.lprezime.Text = "Prezime";
            // 
            // ladresa
            // 
            this.ladresa.AutoSize = true;
            this.ladresa.Location = new System.Drawing.Point(22, 144);
            this.ladresa.Name = "ladresa";
            this.ladresa.Size = new System.Drawing.Size(40, 13);
            this.ladresa.TabIndex = 11;
            this.ladresa.Text = "Adresa";
            // 
            // ljmbg
            // 
            this.ljmbg.AutoSize = true;
            this.ljmbg.Location = new System.Drawing.Point(26, 180);
            this.ljmbg.Name = "ljmbg";
            this.ljmbg.Size = new System.Drawing.Size(36, 13);
            this.ljmbg.TabIndex = 12;
            this.ljmbg.Text = "JMBG";
            // 
            // lemail
            // 
            this.lemail.AutoSize = true;
            this.lemail.Location = new System.Drawing.Point(26, 211);
            this.lemail.Name = "lemail";
            this.lemail.Size = new System.Drawing.Size(32, 13);
            this.lemail.TabIndex = 13;
            this.lemail.Text = "Email";
            // 
            // lPassvord
            // 
            this.lPassvord.AutoSize = true;
            this.lPassvord.Location = new System.Drawing.Point(22, 243);
            this.lPassvord.Name = "lPassvord";
            this.lPassvord.Size = new System.Drawing.Size(44, 13);
            this.lPassvord.TabIndex = 14;
            this.lPassvord.Text = "Lozinka";
            // 
            // lUloga
            // 
            this.lUloga.AutoSize = true;
            this.lUloga.Location = new System.Drawing.Point(26, 279);
            this.lUloga.Name = "lUloga";
            this.lUloga.Size = new System.Drawing.Size(35, 13);
            this.lUloga.TabIndex = 15;
            this.lUloga.Text = "Uloga";
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(33, 343);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(62, 27);
            this.buttonFirst.TabIndex = 16;
            this.buttonFirst.Text = "<<";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // buttonPrev
            // 
            this.buttonPrev.Location = new System.Drawing.Point(33, 310);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(62, 27);
            this.buttonPrev.TabIndex = 17;
            this.buttonPrev.Text = "<";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.buttonAdd.Location = new System.Drawing.Point(37, 376);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(62, 27);
            this.buttonAdd.TabIndex = 18;
            this.buttonAdd.Text = "Dodaj";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUpdate.Location = new System.Drawing.Point(142, 411);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(62, 27);
            this.buttonUpdate.TabIndex = 19;
            this.buttonUpdate.Text = "Izmeni";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.Red;
            this.buttonDelete.Location = new System.Drawing.Point(239, 376);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(62, 27);
            this.buttonDelete.TabIndex = 20;
            this.buttonDelete.Text = "Brisi";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Location = new System.Drawing.Point(239, 310);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(62, 27);
            this.buttonNext.TabIndex = 21;
            this.buttonNext.Text = ">";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(239, 343);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(62, 27);
            this.buttonLast.TabIndex = 22;
            this.buttonLast.Text = ">>";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // Osoba
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(336, 457);
            this.Controls.Add(this.buttonLast);
            this.Controls.Add(this.buttonNext);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.buttonPrev);
            this.Controls.Add(this.buttonFirst);
            this.Controls.Add(this.lUloga);
            this.Controls.Add(this.lPassvord);
            this.Controls.Add(this.lemail);
            this.Controls.Add(this.ljmbg);
            this.Controls.Add(this.ladresa);
            this.Controls.Add(this.lprezime);
            this.Controls.Add(this.lime);
            this.Controls.Add(this.lid);
            this.Controls.Add(this.textBoxUloga);
            this.Controls.Add(this.textBoxLozinka);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxJMBG);
            this.Controls.Add(this.textBoxAdesa);
            this.Controls.Add(this.textBoxPrezime);
            this.Controls.Add(this.textBoxIme);
            this.Controls.Add(this.textBoxId);
            this.Name = "Osoba";
            this.Text = "Osoba";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.TextBox textBoxIme;
        private System.Windows.Forms.TextBox textBoxPrezime;
        private System.Windows.Forms.TextBox textBoxAdesa;
        private System.Windows.Forms.TextBox textBoxJMBG;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxLozinka;
        private System.Windows.Forms.TextBox textBoxUloga;
        private System.Windows.Forms.Label lid;
        private System.Windows.Forms.Label lime;
        private System.Windows.Forms.Label lprezime;
        private System.Windows.Forms.Label ladresa;
        private System.Windows.Forms.Label ljmbg;
        private System.Windows.Forms.Label lemail;
        private System.Windows.Forms.Label lPassvord;
        private System.Windows.Forms.Label lUloga;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonLast;
    }
}

